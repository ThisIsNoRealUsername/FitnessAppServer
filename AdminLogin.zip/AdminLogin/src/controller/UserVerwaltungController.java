package controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.DBManager;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Stage;
import model.Factory;
import model.User;

public class UserVerwaltungController {

	@FXML
	private TableView<User> tbl;
	@FXML
	private TableColumn<User, String> usernameCol;
	@FXML
	private TableColumn<User, String> passwordCol;
	@FXML
	private TableColumn<User, String> firstNameCol;
	@FXML
	private TableColumn<User, String> lastNameCol;
	@FXML
	private TableColumn<User, String> emailCol;
	@FXML
	private TableColumn<User, String> birthDateCol;
	@FXML
	private TableColumn<User, String> bodyHeightCol;
	@FXML
	private TableColumn<User, String> bodyWeightCol;
	@FXML
	private TableColumn<User, String> activityPointsCol;

	@FXML
	private Button btnRead;

	@FXML
	private Button btnAdd;

	@FXML
	private Button btnSave;

	@FXML
	private Button btnDelete;

	private Factory factory = null;
	private Connection con = null;
	private Statement stmt = null;
	private ResultSet rs = null;
	private User u = null;
	
	private void setCellConfigurations() {
		usernameCol.setCellValueFactory(new PropertyValueFactory<User, String>("Username"));
		usernameCol.setCellFactory(TextFieldTableCell.forTableColumn());
		usernameCol.setOnEditCommit(new EventHandler<CellEditEvent<User, String>>() {
			@Override
			public void handle(CellEditEvent<User, String> t) {
				((User) t.getTableView().getItems().get(t.getTablePosition().getRow())).setUsername(t.getNewValue());
			}
		});
		passwordCol.setCellValueFactory(new PropertyValueFactory<User, String>("Password"));
		passwordCol.setCellFactory(TextFieldTableCell.forTableColumn());
		passwordCol.setOnEditCommit(new EventHandler<CellEditEvent<User, String>>() {
			@Override
			public void handle(CellEditEvent<User, String> t) {
				((User) t.getTableView().getItems().get(t.getTablePosition().getRow())).setPassword(t.getNewValue());
			}
		});
		firstNameCol.setCellValueFactory(new PropertyValueFactory<User, String>("FirstName"));
		firstNameCol.setCellFactory(TextFieldTableCell.forTableColumn());
		firstNameCol.setOnEditCommit(new EventHandler<CellEditEvent<User, String>>() {
			@Override
			public void handle(CellEditEvent<User, String> t) {
				((User) t.getTableView().getItems().get(t.getTablePosition().getRow())).setFirstName(t.getNewValue());
			}
		});
		lastNameCol.setCellValueFactory(new PropertyValueFactory<User, String>("LastName"));
		lastNameCol.setCellFactory(TextFieldTableCell.forTableColumn());
		lastNameCol.setOnEditCommit(new EventHandler<CellEditEvent<User, String>>() {
			@Override
			public void handle(CellEditEvent<User, String> t) {
				((User) t.getTableView().getItems().get(t.getTablePosition().getRow())).setLastName(t.getNewValue());
			}
		});
		emailCol.setCellValueFactory(new PropertyValueFactory<User, String>("Email"));
		emailCol.setCellFactory(TextFieldTableCell.forTableColumn());
		emailCol.setOnEditCommit(new EventHandler<CellEditEvent<User, String>>() {
			@Override
			public void handle(CellEditEvent<User, String> t) {
				((User) t.getTableView().getItems().get(t.getTablePosition().getRow())).setEmail(t.getNewValue());
			}
		});
		birthDateCol.setCellValueFactory(new PropertyValueFactory<User, String>("BirthDate"));
		birthDateCol.setCellFactory(TextFieldTableCell.forTableColumn());
		birthDateCol.setOnEditCommit(new EventHandler<CellEditEvent<User, String>>() {
			@Override
			public void handle(CellEditEvent<User, String> t) {
				((User) t.getTableView().getItems().get(t.getTablePosition().getRow())).setBirthDate(t.getNewValue());
			}
		});
		bodyHeightCol.setCellValueFactory(new PropertyValueFactory<User, String>("BodyHeight"));
		bodyHeightCol.setCellFactory(TextFieldTableCell.forTableColumn());
		bodyHeightCol.setOnEditCommit(new EventHandler<CellEditEvent<User, String>>() {
			@Override
			public void handle(CellEditEvent<User, String> t) {
				((User) t.getTableView().getItems().get(t.getTablePosition().getRow())).setBodyHeight(t.getNewValue());
			}
		});
		bodyWeightCol.setCellValueFactory(new PropertyValueFactory<User, String>("BodyWeight"));
		bodyWeightCol.setCellFactory(TextFieldTableCell.forTableColumn());
		bodyWeightCol.setOnEditCommit(new EventHandler<CellEditEvent<User, String>>() {
			@Override
			public void handle(CellEditEvent<User, String> t) {
				((User) t.getTableView().getItems().get(t.getTablePosition().getRow())).setBodyWeight(t.getNewValue());
			}
		});
		activityPointsCol.setCellValueFactory(new PropertyValueFactory<User, String>("ActivityPoints"));
		activityPointsCol.setCellFactory(TextFieldTableCell.forTableColumn());
		activityPointsCol.setOnEditCommit(new EventHandler<CellEditEvent<User, String>>() {
			@Override
			public void handle(CellEditEvent<User, String> t) {
				(t.getTableView().getItems().get(t.getTablePosition().getRow())).setActivityPoints(t.getNewValue());
			}
		});
	}
	
	@FXML
	private void initialize() {
		loadDataFromDatabase();
	}

	@FXML
	private void clickBtnRead() {
		loadDataFromDatabase();
	}
	
	public void loadDataFromDatabase() {
		tbl.getItems().removeAll(tbl.getItems());

		setCellConfigurations();

		try {
			con = DBManager.getConnection();
			stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			rs = stmt.executeQuery("select b.* from user_bsd b");
		} catch (SQLException e) {
			System.err.println("Error at stmt or rs: " + e.getMessage());
		}

		if (rs != null) {
			try {
				while (rs.next()) {
					factory = new Factory(rs);
					u = factory.getUser();
					tbl.getItems().add(u);
				}
			} catch (SQLException e) {
				System.err.println("Error at rs.next(): " + e.getMessage());
			}
		}

		DBManager.close(rs);
		DBManager.close(stmt);
		DBManager.close(con);
	}

	@FXML
	private void clickBtnAdd() {
		try {
			Parent root = FXMLLoader.load(getClass().getClassLoader().getResource("view/AddForm.fxml"));
			Scene scene = new Scene(root,400,450);
			Stage s = new Stage();
			s.setScene(scene);
			s.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@FXML
	private void clickBtnSave() {

		try {
			con = DBManager.getConnection();
			stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			for (User u : tbl.getItems()) {
				stmt.executeUpdate("update user_bsd set username = '" + u.getUsername() + "', firstname = '"
						+ u.getFirstName() + "', lastname = '" + u.getLastName() + "', password = '" + u.getPassword()
						+ "', email = '" + u.getEmail() + "', bodyweight = " + u.getBodyWeight() + ", bodyheight = "
						+ u.getBodyHeight() + ", activitypoints = " + u.getActivityPoints() + ", birthdate =  '"
						+ u.getBirthDate() + "'" + " where id = " + u.getId());
			}
			stmt.execute("commit");
		} catch (SQLException e) {
			System.err.println("Error at stmt or rs: " + e.getMessage());
		}

		DBManager.close(stmt);
		DBManager.close(con);
		clickBtnRead();
	}

	@FXML
	private void clickBtnDelete() {

		if (tbl.getSelectionModel().getSelectedItem() != null) {
			u = tbl.getSelectionModel().getSelectedItem();

			try {
				con = DBManager.getConnection();
				stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
				stmt.executeUpdate("delete from user_bsd where id = " + u.getId());
				stmt.execute("commit");
			} catch (SQLException e) {
				System.err.println("Error at stmt or rs: " + e.getMessage());
			}
		} else
			System.out.println("Nothing selected to delete!");

		DBManager.close(stmt);
		DBManager.close(con);
		clickBtnRead();
	}
}
