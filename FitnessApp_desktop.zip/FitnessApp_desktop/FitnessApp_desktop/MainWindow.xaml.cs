﻿using FitnessApp_desktop.ModelClasses;
using System;
using System.Collections.Generic;
using System.Data;
using System.Device.Location;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FitnessApp_desktop
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
       
        public MainWindow()
        {
            InitializeComponent();
            

        }

        private void loginbtn_Click(object sender, RoutedEventArgs e)
        {
            
            login();
           
        }

        private void OpenRegistering(object sender, MouseButtonEventArgs e)
        {
            (new Register()).Show();
            this.Close();
        }

        private void login()
        {
            try
            {
                DataSet dt = Database.GetReusltFromSelectionString("Select USERNAME,PASSWORD,EMAIL,FIRSTNAME,LASTNAME,EMAIL,BODYWEIGHT,BODYHEIGHT,ACTIVITYPOINTS,BIRTHDATE from User_Bsd where EMAIL ='" + this.unOemtxt.Text + "' And  PASSWORD ='" + this.pwtxt.Password + "' or USERNAME ='" + this.unOemtxt.Text + "' And  PASSWORD ='" + this.pwtxt.Password + "'");
                if (dt.Tables[0].Rows.Count == 1)
                {

                    MainWindow_FA.LOGGEDINUSER = new User(dt.Tables[0].Rows[0]["username"].ToString(), dt.Tables[0].Rows[0]["firstname"].ToString(), dt.Tables[0].Rows[0]["lastname"].ToString(), dt.Tables[0].Rows[0]["email"].ToString(), dt.Tables[0].Rows[0]["password"].ToString(),
                        Convert.ToInt32(dt.Tables[0].Rows[0]["bodyweight"].ToString()), Convert.ToInt32(dt.Tables[0].Rows[0]["bodyheight"].ToString()), Convert.ToInt32(dt.Tables[0].Rows[0]["activitypoints"].ToString()), dt.Tables[0].Rows[0]["birthdate"].ToString());
                    (new MainWindow_FA()).Show();
                    this.Close();
                }

                else
                    MessageBox.Show("Wrong Password or Username");
            }

            catch (Exception exc)
            {
                MessageBox.Show("error occured in login\ntry again later");
            }
        }


        private void pwtxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
            login();
        }
    }
}