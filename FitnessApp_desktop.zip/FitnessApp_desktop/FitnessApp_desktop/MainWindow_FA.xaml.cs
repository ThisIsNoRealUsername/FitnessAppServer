﻿using FitnessApp_desktop.ModelClasses;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.DataVisualization.Charting;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace FitnessApp_desktop
{
    /// <summary>
    /// Interaction logic for MainWindow_FA.xaml
    /// </summary>

    public partial class MainWindow_FA : Window
    {
        internal static User LOGGEDINUSER = null;
        private Thread ThreadForClock = null;

        private static Boolean ISONEDAY = false;
        private static List<KeyValuePair<string, int>> allKeyValuePairs = null;
        private static int MAXCOUNTXAXIS = 18;
        private static DateTime FROM;
        private static DateTime TO;
        private static List<DateTime> AllDates = new List<DateTime>();

        public MainWindow_FA()
        {
            InitializeComponent();
            if (LOGGEDINUSER == null) throw new Exception("no User found to continue");
            this.LoggedInUsertxt.Content = LOGGEDINUSER.username;
            ThreadForClock = new Thread(Clocking);
            ThreadForClock.Start();
            comboBox_training.SelectedIndex = 0;
            CmbChartStyle.SelectedIndex = 0;
        }

        private void Clocking()
        {
            while (true)
            {
                this.Dispatcher.Invoke(() => { this.Clocktxt.Content = DateTime.Now.ToString(); });
                Thread.Sleep(100);
            }
        }

        private void FillWithWorkouts(object sender, SelectionChangedEventArgs e)
        {
            comboBox_workout.Items.Clear();
            cmbColumns.Items.Clear();
            switch ((comboBox_training.SelectedItem as ComboBoxItem).Content.ToString())
            {
                case "Cardio":
                    comboBox_workout.Items.Add("Run");
                    comboBox_workout.Items.Add("Swim");
                    comboBox_workout.Items.Add("Cycle");
                    cmbColumns.Items.Add("Hoehenmeter");
                    cmbColumns.Items.Add("Zeit");
                    cmbColumns.Items.Add("Kilometer");
                    break;
                case "Power":
                    comboBox_workout.Items.Add("Benchpress");
                    comboBox_workout.Items.Add("Squat");
                    comboBox_workout.Items.Add("Deadlift");
                    cmbColumns.Items.Add("Gewichte");
                    cmbColumns.Items.Add("Wiederholungen");

                    break;
            }
            comboBox_workout.SelectedIndex = 0;
            cmbColumns.SelectedIndex = 0;
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ISONEDAY = false;
                Mouse.OverrideCursor = Cursors.Wait;



                FROM = DatePickerFirst.SelectedDate.Value;

                TO = DatePickerSecond.SelectedDate.Value;

                FillListDates();
                if (FROM == TO)
                    ISONEDAY = true;

                ChartOfData.Series.Clear();

                SetIntervalForChart();
                if (ISONEDAY)
                {
                    xAxis.Minimum = Convert.ToDateTime(FROM.AddDays(-1));
                    xAxis.Maximum = Convert.ToDateTime(TO.AddDays(1));
                }
                else
                {
                    xAxis.Minimum = Convert.ToDateTime(FROM);
                    xAxis.Maximum = Convert.ToDateTime(TO);
                }
                xAxis.IntervalType = DateTimeIntervalType.Days;



                allKeyValuePairs = null;

                switch ((CmbChartStyle.SelectedItem as Label).Content.ToString())
                {
                    case "BarChart":
                        CreateBarChartFromDataSet();
                        break;
                    case "LineChart":
                        CreateLineChartFromDataSet();
                        break;
                    case "BubbleChart":
                        CreateBubbleChartFromDataSet();
                        break;
                    case "AreaChart":
                        CreateAreaChartFromDataSet();
                        break;
                    case "ScatterChart":
                        CreateScatterChartFromDataSet();
                        break;
                }

                Mouse.OverrideCursor = Cursors.Arrow;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Choose values correctly!");
                Mouse.OverrideCursor = Cursors.Arrow;
            }
        }

        private void FillListDates()
        {
            MainWindow_FA.AllDates.Clear();
            for (DateTime count = FROM; count < TO; count = count.AddDays(+1))
            {
                MainWindow_FA.AllDates.Add(count);
            }
        }

        private void SetIntervalForChart()
        {


            xAxis.Interval = AllDates.Count / MAXCOUNTXAXIS;


        }


        private void CreateBarChartFromDataSet()
        {
            try
            {
                ChartOfData.Series.Clear();

                ColumnSeries training = new ColumnSeries();
                training.Title = cmbColumns.SelectedValue as string;
                ChartOfData.Series.Add(training);


                (ChartOfData.Series[0] as ColumnSeries).DependentValueBinding = new Binding("Value");
                (ChartOfData.Series[0] as ColumnSeries).IndependentValueBinding = new Binding("Key");
                (ChartOfData.Series[0] as ColumnSeries).ItemsSource = GetSumKeyValuePairs();


            }
            catch (Exception ex)
            {
                throw (new Exception("Error in buildng the Chart!\n" + ex.Message));
            }
        }
        private void CreateBubbleChartFromDataSet()
        {
            try
            {
                ChartOfData.Series.Clear();

                BubbleSeries training = new BubbleSeries();
                training.Title = cmbColumns.SelectedValue as string;
                ChartOfData.Series.Add(training);


                (ChartOfData.Series[0] as BubbleSeries).DependentValueBinding = new Binding("Value");
                (ChartOfData.Series[0] as BubbleSeries).IndependentValueBinding = new Binding("Key");
                (ChartOfData.Series[0] as BubbleSeries).ItemsSource = GetSumKeyValuePairs();


            }
            catch (Exception ex)
            {
                throw (new Exception("Error in buildng the Chart!\n" + ex.Message));
            }
        }
        private void CreateAreaChartFromDataSet()
        {
            try
            {
                ChartOfData.Series.Clear();

                AreaSeries training = new AreaSeries();
                training.Title = cmbColumns.SelectedValue as string;
                ChartOfData.Series.Add(training);


                (ChartOfData.Series[0] as AreaSeries).DependentValueBinding = new Binding("Value");
                (ChartOfData.Series[0] as AreaSeries).IndependentValueBinding = new Binding("Key");
                (ChartOfData.Series[0] as AreaSeries).ItemsSource = GetSumKeyValuePairs();


            }
            catch (Exception ex)
            {
                throw (new Exception("Error in buildng the Chart!\n" + ex.Message));
            }
        }
        private void CreateLineChartFromDataSet()
        {
            try
            {
                ChartOfData.Series.Clear();

                LineSeries training = new LineSeries();
                training.Title = cmbColumns.SelectedValue as string;
                ChartOfData.Series.Add(training);


                (ChartOfData.Series[0] as LineSeries).DependentValueBinding = new Binding("Value");
                (ChartOfData.Series[0] as LineSeries).IndependentValueBinding = new Binding("Key");
                (ChartOfData.Series[0] as LineSeries).ItemsSource = GetSumKeyValuePairs();


            }
            catch (Exception ex)
            {
                throw (new Exception("Error in buildng the Chart!\n" + ex.Message));
            }
        }
        private void CreateScatterChartFromDataSet()
        {
            try
            {
                ChartOfData.Series.Clear();

                ScatterSeries training = new ScatterSeries();
                training.Title = cmbColumns.SelectedValue as string;
                ChartOfData.Series.Add(training);


                (ChartOfData.Series[0] as ScatterSeries).DependentValueBinding = new Binding("Value");
                (ChartOfData.Series[0] as ScatterSeries).IndependentValueBinding = new Binding("Key");
                (ChartOfData.Series[0] as ScatterSeries).ItemsSource = GetSumKeyValuePairs();


            }
            catch (Exception ex)
            {
                throw (new Exception("Error in buildng the Chart!\n" + ex.Message));
            }
        }

        private List<KeyValuePair<DateTime, double>> GetSumKeyValuePairs()
        {
            List<KeyValuePair<DateTime, double>> ret = new List<KeyValuePair<DateTime, double>>();
            string query;
            if (comboBox_training.SelectedValue.ToString().Split(':')[1].Trim() == "Cardio")
                query = "Select c.id_user, c.un_user, c.email_user, c.activitypoints, r.id, r.hoehenmeter, r.kilometer, to_char(r.zeit, 'hh24:mi:ss') as Zeit, to_char(c.c_date, 'dd.mm.yyyy') as C_DATE from " + comboBox_workout.SelectedValue.ToString() + "_bsd r join " + comboBox_training.SelectedValue.ToString().Split(':')[1].Trim() + "_bsd c on r.id = c.id where c.c_date between to_date('" + FROM.ToShortDateString() + "','dd.mm.yyyy') and to_date('" + TO.ToShortDateString() + "','dd.mm.yyyy') and c.un_user like '" + this.LoggedInUsertxt.Content + "'";
            else
                query = "Select c.id_user, c.un_user, c.email_user, c.activitypoints, r.id, r.Gewichte, r.Wiederholungen, to_char(c.c_date, 'dd.mm.yyyy') as C_DATE from " + comboBox_workout.SelectedValue.ToString() + "_bsd r join " + comboBox_training.SelectedValue.ToString().Split(':')[1].Trim() + "_bsd c on r.id = c.id where c.c_date between to_date('" + FROM.ToShortDateString() + "','dd.mm.yyyy') and to_date('" + TO.ToShortDateString() + "','dd.mm.yyyy') and c.un_user like '" + this.LoggedInUsertxt.Content + "'";
            DataTable dataTblDataToShow = Database.GetReusltFromSelectionString(query).Tables["FilledTable"];

            string col = cmbColumns.SelectedValue as string;
            Parallel.ForEach(AllDates, dt =>
                    {
                        String s = dt.ToShortDateString();
                        //Database.GetReusltFromSelectionString
                        KeyValuePair<DateTime, double> k;
                        string f = string.Format("{0}='{1}'", "C_DATE", dt.ToShortDateString());
                        DataRow[] dr = dataTblDataToShow.Select(f);
                        if (dr.Length == 0)
                        {
                            k = new KeyValuePair<DateTime, double>(dt, 0);
                        }
                        else
                        {
                            if (col == "Zeit")
                            {
                                DateTime t = Convert.ToDateTime(dr[0][col]);
                                double time = (double)((t.Hour * 60F) + t.Minute + (t.Second / 60F));
                                k = new KeyValuePair<DateTime, double>(dt, Math.Round(time, 2));
                            }
                            else
                                k = new KeyValuePair<DateTime, double>(dt, Convert.ToInt32(dr[0][col]));
                        }
                        lock (ret)
                        {
                            ret.Add(k);
                        }


                    });




            return ret;
        }

        private void libraryBtn_Click(object sender, RoutedEventArgs e)
        {
            new library().Show();
        }
    }
}

