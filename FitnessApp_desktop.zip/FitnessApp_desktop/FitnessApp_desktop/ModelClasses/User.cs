﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FitnessApp_desktop.ModelClasses
{
    class User
    {
        public string username
        {
            get;
        }
        public string firstname
        {
            get;
        }
        public string lastname
        {
            get;
        }
        public string email
        {
            get;
        }
        public string password
        {
            get;
        }
        public int bodyweight
        {
            get;
        }
        public int bodyheight
        {
            get;
        }
        public int activityPoints
        {
            get;
        }
        public string birthdate
        {
            get;
        }


        public User(string un, string fn, string ln, string email, string pw, int bw, int bh, int aP, string bd)
        {
            this.username = un;
            this.firstname = fn;
            this.lastname = ln;
            this.email = email;
            this.password = pw;
            this.bodyweight = bw;
            this.bodyheight = bh;
            this.activityPoints = aP;
            this.birthdate = bd;
        }
    }
}
