﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace FitnessApp_desktop
{
    
    class Database
    {
        static  private string ipExtern = "212.152.179.117";
        static private string ipIntern = "192.168.128.152";
        static public string  ap = "aphrodite4";
        //static public string ap = "212.152.179.117";
        private static String connectionString = "Provider=OraOLEDB.Oracle; Data Source="+ipIntern+ "/ora11g; User Id = d5a03; Password = d5a; OLEDB.NET = True;";
        static private OleDbConnection ConnectionToDB = null;
        public static DataSet GetReusltFromSelectionString(string query)
        {
            try {
                OpenConnection();
                DataSet ResultSet = new DataSet();
                OleDbDataAdapter Adapter = new OleDbDataAdapter(query, ConnectionToDB);
                Adapter.Fill(ResultSet, "FilledTable");
                CloseAllCOnnections();
                return ResultSet;
            }catch(Exception ex)
            {
                return new DataSet();
            }
            
        }

        public static int InsertQuery(string query)
        {
            
            OpenConnection();
            int result;
            OleDbDataAdapter Adapter = new OleDbDataAdapter();
            Adapter.InsertCommand = new OleDbCommand(query, ConnectionToDB);
            result = Adapter.InsertCommand.ExecuteNonQuery();
           
            CloseAllCOnnections();
            return result;

        }
        static private void OpenConnection()
        {
            if(ConnectionToDB== null)
            {
                ConnectionToDB = new OleDbConnection(connectionString);
            }

            if (ConnectionToDB.State != ConnectionState.Open)
            {
               
                
                    try
                    {
                   
                    ConnectionToDB = new OleDbConnection(connectionString);
                    ConnectionToDB.Open();
                        Console.WriteLine("DataSource: {0} \nDatabase: {1}",
                            ConnectionToDB.DataSource, ConnectionToDB.Database);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    // The connection is automatically closed when the
                    // code exits the using block.
                
            }
        }
        static void CloseAllCOnnections()
        {
            ConnectionToDB.Close();
        }

    }
}
