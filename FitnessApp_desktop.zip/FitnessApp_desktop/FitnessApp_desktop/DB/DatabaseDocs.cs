﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FitnessApp_desktop.DB
{
    class DatabaseDocs
    {
        static private string ipExtern = "212.152.179.117";
        static private string ipIntern = "192.168.128.152";
        static private string ap = "aphrodite4";
        private static String connectionString = "Provider=OraOLEDB.Oracle; Data Source=" + ipIntern + "/ora11g; User Id = ctxsys; Password = ctxsys; OLEDB.NET = True;";
        static private OleDbConnection ConnectionToDB = null;
        public static DataView GetReusltFromSelectionString(string query)
        {
            try
            {
                OpenConnection();
                DataTable ResultSet = new DataTable();
                OleDbDataAdapter Adapter = new OleDbDataAdapter(query, ConnectionToDB);
                Adapter.Fill(ResultSet);
                CloseAllConnections();
                return ResultSet.DefaultView;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return new DataView();


        }

      
        static private void OpenConnection()
        {
            if (ConnectionToDB == null)
            {
                ConnectionToDB = new OleDbConnection(connectionString);
            }

            if (ConnectionToDB.State != ConnectionState.Open)
            {


                try
                {

                    ConnectionToDB = new OleDbConnection(connectionString);
                    ConnectionToDB.Open();
                    Console.WriteLine("DataSource: {0} \nDatabase: {1}",
                        ConnectionToDB.DataSource, ConnectionToDB.Database);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                // The connection is automatically closed when the
                // code exits the using block.

            }
        }
        static void CloseAllConnections()
        {
            ConnectionToDB.Close();
        }

    }
}