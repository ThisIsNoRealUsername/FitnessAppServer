﻿using FitnessApp_desktop.ModelClasses;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FitnessApp_desktop
{
    /// <summary>
    /// Interaction logic for Register.xaml
    /// </summary>
    public partial class Register : Window
    {
        public Register()
        {
            InitializeComponent();
        }

        private void register_btn_Click(object sender, RoutedEventArgs e)
        {
            DataSet dt = Database.GetReusltFromSelectionString("Select * from User_Bsd where email = '"+this.email_txt.Text+"'");
            if (dt.Tables[0].Rows.Count == 0)
            {
                dt = Database.GetReusltFromSelectionString("Select * from User_Bsd where username = '" + this.username_txt.Text + "'");
                if (dt.Tables[0].Rows.Count == 0)
                {
                    if (password_txt.Password == repeat_pw_txt.Password)
                    {
                        RegisterToDB();
                    }
                    else MessageBox.Show("Password wrong");
                }
                else
                MessageBox.Show("username already in use");

            }
            else
            MessageBox.Show("Email already in use");

        }

        private void RegisterToDB()
        {
            MainWindow_FA.LOGGEDINUSER = new User(this.username_txt.Text, this.firstname_txt.Text, this.lastname_txt.Text, this.email_txt.Text, this.password_txt.Password, Convert.ToInt32(this.bodyweight_txt.Text), Convert.ToInt32(this.bodyheight_txt.Text), 0, birthdate_datepicker.Text);
            string query = "insert into USER_BSD values(1,'"+MainWindow_FA.LOGGEDINUSER.username+"','" + MainWindow_FA.LOGGEDINUSER.firstname + "','" + MainWindow_FA.LOGGEDINUSER.lastname + "','" + MainWindow_FA.LOGGEDINUSER.password + "','" + MainWindow_FA.LOGGEDINUSER.email + "'," + MainWindow_FA.LOGGEDINUSER.bodyweight + "," + MainWindow_FA.LOGGEDINUSER.bodyheight + ",0,'" + MainWindow_FA.LOGGEDINUSER.birthdate + "')";
            if (Database.InsertQuery(query) == 1)
                MessageBox.Show("you are now registered");
            (new MainWindow_FA()).Show();
            this.Close();
        }
    }
}
