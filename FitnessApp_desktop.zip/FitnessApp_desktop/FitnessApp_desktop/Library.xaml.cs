﻿using FitnessApp_desktop.DB;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FitnessApp_desktop
{
    /// <summary>
    /// Interaction logic for library.xaml
    /// </summary>
    public partial class library : Window
    {
        private static string CRYPTSTRING = null;
        public library()
        {
            try
            {
                InitializeComponent();
                string sql = "SELECT * FROM DOCS_03 order by title";
                dataGrid.ItemsSource = DatabaseDocs.GetReusltFromSelectionString(sql);
               
                CryptBtn.Visibility = Visibility.Hidden;
            }
            catch (Exception exe)
            {
                MessageBox.Show(exe.ToString());
            }
        }


        private void btnHTML_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                CryptBtn.Visibility = Visibility.Visible;
                CryptBtn.Content = "Encrypt";
                string file = ((DataRowView)dataGrid.SelectedItem).Row.ItemArray.GetValue(1).ToString();
                DataView dv = DatabaseDocs.GetReusltFromSelectionString("select text from DOCS_03 where title = '" + file + "'");
                var str = dv.Table.Rows[0].ItemArray.GetValue(0);
                CRYPTSTRING = System.Text.Encoding.Default.GetString((byte[])str);
                using (StreamWriter outputFile = new StreamWriter("./test.html"))
                {
                    outputFile.WriteLine(CRYPTSTRING);
                }
                Assembly ass = Assembly.GetExecutingAssembly();
                string path = System.IO.Path.GetDirectoryName(ass.Location);
                System.Diagnostics.Process.Start(path + "/test.html");
            }
            catch (Exception exe)
            {
                MessageBox.Show(exe.ToString());
            }

        }

        private void Encrypt()
        {
            string newEncrypted = CRYPTSTRING;

            RijndaelManaged RMCrypto = new RijndaelManaged();
            FileStream fs = new FileStream("./test.html", FileMode.OpenOrCreate);
            byte[] Key = { 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16 };
            byte[] IV = { 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16 };

            //Create a CryptoStream, pass it the NetworkStream, and encrypt 
            //it with the Rijndael class.
            CryptoStream CryptStream = new CryptoStream(fs,
            RMCrypto.CreateEncryptor(Key, IV),
            CryptoStreamMode.Write);
            StreamWriter SWriter = new StreamWriter(CryptStream);
            SWriter.WriteLine(newEncrypted);
            SWriter.Close();
            CryptStream.Close();
            fs.Close();

        }

        

        private void CryptBtn_Click(object sender, RoutedEventArgs e)
        {

            if (CryptBtn.Content.ToString() == "Encrypt")
            {
                Encrypt();
                CryptBtn.Content = "Decrypt";
            }
            else
            {
                Decrypt();
                CryptBtn.Content = "Encrypt";
                using (StreamWriter outputFile = new StreamWriter("./test.html"))
                {
                    outputFile.WriteLine(CRYPTSTRING);
                }
            }



            Assembly ass = Assembly.GetExecutingAssembly();
            string path = System.IO.Path.GetDirectoryName(ass.Location);
            System.Diagnostics.Process.Start(path + "/test.html");



        }

        private void Decrypt()
        {

            RijndaelManaged RMCrypto = new RijndaelManaged();
            FileStream fs = new FileStream("./test.html", FileMode.OpenOrCreate);
            byte[] Key = { 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16 };
            byte[] IV = { 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16 };

            //Create a CryptoStream, pass it the NetworkStream, and encrypt 
            //it with the Rijndael class.
            CryptoStream CryptStream = new CryptoStream(fs,
            RMCrypto.CreateDecryptor(Key, IV),
            CryptoStreamMode.Read);
            StreamReader Sr = new StreamReader(CryptStream);
            CRYPTSTRING = Sr.ReadToEnd();
            Sr.Close();
            CryptStream.Close();
            fs.Close();


        }

        private void SelectBtn_Click(object sender, RoutedEventArgs e)
        {
            dataGrid.ItemsSource = DatabaseDocs.GetReusltFromSelectionString(selectTxt.Text);
            CryptBtn.Visibility = Visibility.Hidden;
        }
    }
}